package com.booking;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

class FacilityBookingc {
    private String facilityName;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private double bookingAmount;

    public FacilityBookingc(String facilityName, LocalDateTime startTime, LocalDateTime endTime, double bookingAmount) {
        this.facilityName = facilityName;
        this.startTime = startTime;
        this.endTime = endTime;
        this.bookingAmount = bookingAmount;
    }

    public String getFacilityName() {
        return facilityName;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public double getBookingAmount() {
        return bookingAmount;
    }
}

class FacilityBookingcManager {
    private Map<String, FacilityBooking> bookings;

    public FacilityBookingcManager() {
        this.bookings = new HashMap<>();
    }

    public String bookFacility(String facilityName, String startDateTime, String endDateTime) {
        LocalDateTime startTime = LocalDateTime.parse(startDateTime, DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm"));
        LocalDateTime endTime = LocalDateTime.parse(endDateTime, DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm"));

        // Check if the facility is already booked for the given time slot
        if (isFacilityAlreadyBooked(facilityName, startTime, endTime)) {
            return "Booking Failed, Already Booked";
        }

        double bookingAmount = calculateBookingAmount(facilityName, startTime, endTime);
        FacilityBooking booking = new FacilityBooking(facilityName, startTime, endTime, bookingAmount);
        bookings.put(facilityName, booking);

        return "Booked, Rs. " + bookingAmount;
    }

    private boolean isFacilityAlreadyBooked(String facilityName, LocalDateTime startTime, LocalDateTime endTime) {
        for (FacilityBooking booking : bookings.values()) {
            LocalDateTime existingStartTime = booking.getStartTime();
            LocalDateTime existingEndTime = booking.getEndTime();

            if ((startTime.isAfter(existingStartTime) && startTime.isBefore(existingEndTime))
                    || (endTime.isAfter(existingStartTime) && endTime.isBefore(existingEndTime))
                    || (startTime.isBefore(existingStartTime) && endTime.isAfter(existingEndTime))) {
                return true;
            }
        }

        return false;
    }

    private double calculateBookingAmount(String facilityName, LocalDateTime startTime, LocalDateTime endTime) {
        if (facilityName.equals("Clubhouse")) {
            if (startTime.isBefore(startTime.withHour(16))) {
                endTime = endTime.withHour(16);
            } else if (endTime.isAfter(endTime.withHour(22))) {
                startTime = startTime.withHour(22);
            }
            long hours1 = startTime.until(endTime, java.time.temporal.ChronoUnit.HOURS);
            long hours2 = endTime.until(startTime.withHour(22), java.time.temporal.ChronoUnit.HOURS);
            long hours3 = startTime.withHour(16).until(startTime, java.time.temporal.ChronoUnit.HOURS);
            return hours1 * 500 + hours2 * 500 + hours3 * 100;
        } 

        return 0;
    }
}

public class Clubhouse {
    public static void main(String[] args) {
        FacilityBookingManager bookingManager = new FacilityBookingManager();

        // Scenario 1
        String bookingStatus1 = bookingManager.bookFacility("Clubhouse", "26-10-2020 16:00", "26-10-2020 22:00");
        System.out.println(bookingStatus1); // Expected output: Booked, Rs. 1000

        // Scenario 2
        String bookingStatus2 = bookingManager.bookFacility("Tennis Court", "26-10-2020 16:00", "26-10-2020 20:00");
        System.out.println(bookingStatus2); // Expected output: Booked, Rs. 200

        // Scenario 3
        String bookingStatus3 = bookingManager.bookFacility("Clubhouse", "26-10-2020 16:00", "26-10-2020 22:00");
        System.out.println(bookingStatus3); // Expected output: Booking Failed, Already Booked

       
    }
}
