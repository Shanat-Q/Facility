package com.booking.controller;
import java.time.LocalTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//import com.booking.service.FacilityBookingService;

@RestController
@RequestMapping("/api/bookings")
public class FacilityBookingController {
	
//    private FacilityBookingService facilityBookingService;
//
//    public FacilityBookingController(FacilityBookingService facilityBookingService) {
//        this.facilityBookingService = facilityBookingService;
//    }

//    @PostMapping("/checkAvailability")
//    public ResponseEntity<String> checkFacilityAvailability(
//            @RequestParam String facilityId,
//            @RequestParam String startTime,
//            @RequestParam String endTime
//    ) {
//        try {
//            LocalTime start = LocalTime.parse(startTime);
//            LocalTime end = LocalTime.parse(endTime);
//
//            boolean isAvailable = facilityBookingService.isFacilityAvailable(facilityId, start, end);
//            if (isAvailable) {
//                return ResponseEntity.ok("Facility is available for booking.");
//            } else {
//                return ResponseEntity.ok("Facility is not available for the specified time slot.");
//            }
//        } catch (Exception e) {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid request parameters.");
//        }
//    }
//
//    @PostMapping("/book")
//    public ResponseEntity<String> bookFacility(
//            @RequestParam String facilityId,
//            @RequestParam String startTime,
//            @RequestParam String endTime
//    ) {
//        try {
//            LocalTime start = LocalTime.parse(startTime);
//            LocalTime end = LocalTime.parse(endTime);
//
//            boolean isAvailable = facilityBookingService.isFacilityAvailable(facilityId, start, end);
//            if (isAvailable) {
//                facilityBookingService.makeBooking(facilityId, start, end);
//                return ResponseEntity.ok("Facility booked successfully.");
//            } else {
//                return ResponseEntity.ok("Facility is not available for the specified time slot.");
//            }
//        } catch (Exception e) {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid request parameters.");
//        }
//    }
	
	
	
	@GetMapping("/test")
	String check() {
		return "Working ";
	}
}
