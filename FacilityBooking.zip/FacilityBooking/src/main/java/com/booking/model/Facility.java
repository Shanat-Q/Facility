package com.booking.model;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
//
//@Entity
//@Table("Facility")
public class Facility {
    @Override
	public int hashCode() {
		return Objects.hash(bookingRates, id, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Facility other = (Facility) obj;
		return Objects.equals(bookingRates, other.bookingRates) && Objects.equals(id, other.id)
				&& Objects.equals(name, other.name);
	}

	private String id;
    private String name;
    
    private Map<TimeSlot, Double> bookingRates;

    public Facility(String id, String name) {
        this.id = id;
        this.name = name;
        this.bookingRates = new HashMap<>();
    }

    public void addBookingRate(TimeSlot timeSlot, double rate) {
        bookingRates.put(timeSlot, rate);
    }

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map<TimeSlot, Double> getBookingRates() {
		return bookingRates;
	}

	public void setBookingRates(Map<TimeSlot, Double> bookingRates) {
		this.bookingRates = bookingRates;
	}

    
}
