package com.booking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookingfaciltyApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookingfaciltyApplication.class, args);
	}

}
