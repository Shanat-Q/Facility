package com.booking;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

class FacilityBooking {
    private String facilityName;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private double bookingAmount;

    public FacilityBooking(String facilityName, LocalDateTime startTime, LocalDateTime endTime, double bookingAmount) {
        this.facilityName = facilityName;
        this.startTime = startTime;
        this.endTime = endTime;
        this.bookingAmount = bookingAmount;
    }

    public String getFacilityName() {
        return facilityName;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public double getBookingAmount() {
        return bookingAmount;
    }
}

class FacilityBookingManager {
    private Map<String, FacilityBooking> bookings;
    private Map<String, Double> facilityConfigurations;

    public FacilityBookingManager() {
        this.bookings = new HashMap<>();
        this.facilityConfigurations = new HashMap<>();
        // Configuration for Tennis Court facility
        facilityConfigurations.put("Tennis Court", 50.0);
    }

    public String bookFacility(String facilityName, String date, String startTime, String endTime) {
        LocalDateTime bookingDateTime = LocalDateTime.parse(date + " " + startTime, DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm"));
        LocalDateTime bookingEndDateTime = LocalDateTime.parse(date + " " + endTime, DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm"));

        // Check if the facility is already booked for the given time slot
        if (isFacilityAlreadyBooked(facilityName, bookingDateTime, bookingEndDateTime)) {
            return "Booking Failed, Already Booked";
        }

        double bookingAmount = calculateBookingAmount(facilityName, bookingDateTime, bookingEndDateTime);
        FacilityBooking booking = new FacilityBooking(facilityName, bookingDateTime, bookingEndDateTime, bookingAmount);
        bookings.put(facilityName, booking);

        return "Booked, Rs. " + bookingAmount;
    }

    private boolean isFacilityAlreadyBooked(String facilityName, LocalDateTime startTime, LocalDateTime endTime) {
        for (FacilityBooking booking : bookings.values()) {
            LocalDateTime existingStartTime = booking.getStartTime();
            LocalDateTime existingEndTime = booking.getEndTime();

            if ((startTime.isAfter(existingStartTime) && startTime.isBefore(existingEndTime))
                    || (endTime.isAfter(existingStartTime) && endTime.isBefore(existingEndTime))
                    || (startTime.isBefore(existingStartTime) && endTime.isAfter(existingEndTime))) {
                return true;
            }
        }

        return false;
    }

    private double calculateBookingAmount(String facilityName, LocalDateTime startTime, LocalDateTime endTime) {
        Double facilityRate = facilityConfigurations.get(facilityName);
        if (facilityRate != null) {
            long hours = startTime.until(endTime, java.time.temporal.ChronoUnit.HOURS);
            return hours * facilityRate;
        }

        return 0.0;
    }
}

public class TennisCourt {
    public static void main(String[] args) {
        FacilityBookingManager bookingManager = new FacilityBookingManager();

        // Scenario 1
        String bookingStatus1 = bookingManager.bookFacility("Tennis Court", "26-10-2020", "16:00", "20:00");
        System.out.println(bookingStatus1); // Expected output: Booked, Rs. 200

        // Scenario 2
        String bookingStatus2 = bookingManager.bookFacility("Tennis Court", "26-10-2020", "17:00", "21:00");
        System.out.println(bookingStatus2); // Expected output: Booking Failed, Already Booked
    }
}
