package com.booking.model;

import java.util.HashMap;
import java.util.Map;
//
//@Entity
//@Table("Facility")
public class Facility {
    private String id;
    private String name;
    
    private Map<TimeSlot, Double> bookingRates;

    public Facility(String id, String name) {
        this.id = id;
        this.name = name;
        this.bookingRates = new HashMap<>();
    }

    public void addBookingRate(TimeSlot timeSlot, double rate) {
        bookingRates.put(timeSlot, rate);
    }

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map<TimeSlot, Double> getBookingRates() {
		return bookingRates;
	}

	public void setBookingRates(Map<TimeSlot, Double> bookingRates) {
		this.bookingRates = bookingRates;
	}

    
}
