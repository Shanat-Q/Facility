//package com.booking.service;
//
//import java.time.LocalTime;
//import java.util.HashMap;
//import java.util.Map;
//
//import org.springframework.stereotype.Service;
//
//import com.booking.model.Facility;
//import com.booking.model.TimeSlot;
//import java.time.Duration;
//import java.time.LocalTime;
//
//@Service
//public class FacilityBookingService {
//    private Map<String, Facility> facilities;
//
//    public FacilityBookingService() {
//        this.facilities = new HashMap<>();
//    }
//
//    public void addFacility(Facility facility) {
//        facilities.put(facility.getId(), facility);
//    }
//
//    public boolean isFacilityAvailable(String facilityId, LocalTime startTime, LocalTime endTime) {
//        Facility facility = facilities.get(facilityId);
//        if (facility == null) {
//            return false;
//        }
//
//        // Check if the time slot is available
//        for (TimeSlot timeSlot : facility.getBookingRates().keySet()) {
//            if (startTime.isAfter(timeSlot.getStartTime()) && endTime.isBefore(timeSlot.getEndTime())) {
//                return true;
//            }
//        }
//
//        return false;
//    }
//
//    public double calculateBookingAmount(String facilityId, LocalTime startTime, LocalTime endTime) {
//        Facility facility = facilities.get(facilityId);
//        if (facility == null) {
//            return 0.0;
//        }
//
//        // Find the applicable booking rate based on the time slot
//        for (Map.Entry<TimeSlot, Double> entry : facility.getBookingRates().entrySet()) {
//            TimeSlot timeSlot = entry.getKey();
//            double rate = entry.getValue();
//
//            if (startTime.isAfter(timeSlot.getStartTime()) && endTime.isBefore(timeSlot.getEndTime())) {
//                long hours = Duration.between(startTime, endTime).toHours();
//                return rate * hours;
//            }
//        }
//
//        return 0.0;
//    }
//
//    public void makeBooking(String facilityId, LocalTime startTime, LocalTime endTime) {
//        Facility facility = facilities.get(facilityId);
//        if (facility == null) {
//            // Facility not found, handle the error
//            return;
//        }
//
//        // Check if the facility is available for the given time slot
//        if (!isFacilityAvailable(facilityId, startTime, endTime)) {
//            // Facility not available, handle the error
//            return;
//        }
//
//        // Calculate the booking amount
//        double bookingAmount = calculateBookingAmount(facilityId, startTime, endTime);
//
//        // Perform the booking
//        //Now  Add our code here to handle the booking (e.g., update a database, send confirmation, etc.)
//    }
//}
